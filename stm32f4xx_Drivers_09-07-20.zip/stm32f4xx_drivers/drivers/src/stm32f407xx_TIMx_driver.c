/*
 * stm32f407xx_TIMx_driver.c
 *
 *  Created on: 3 Jul 2020
 *      Author: cchar
 */


#include "stm32f407xx_TIMx_driver.h"

//Peripheral Clock setup

/******************************************************************************
 * @fn				- TIM_PeriClkCtrl
 *
 * @brief			- this function enables or disables peripheral clock for a given TIM port
 *
 * @param[in]		- base address of the TIM peripheral
 * @param[in]		- Enable or Disable macros
 * @param[in]		-
 * @param[in]		-
 *
 * @Return			- none
 *
 * @Note			- none
 *
 */

void TIMx_PeriClkCtrl(TIMx_RegDef_t *pTIMx, uint8_t TIM_Num, uint8_t EnorDi)
{

	if(TIM_Num == 1)
	{
		TIM1_8_PeriClkCtrl(pTIMx->pTIM1_8, EnorDi);
	}
	else if(TIM_Num == 2)
	{
		TIM2_5_PeriClkCtrl(pTIMx->pTIM2_5, EnorDi);
	}
	else if(TIM_Num == 3)
	{
		TIM2_5_PeriClkCtrl(pTIMx->pTIM2_5, EnorDi);
	}
	else if(TIM_Num == 4)
	{
		TIM2_5_PeriClkCtrl(pTIMx->pTIM2_5, EnorDi);
	}
	else if(TIM_Num == 5)
	{
		TIM2_5_PeriClkCtrl(pTIMx->pTIM2_5, EnorDi);
	}
	else if(TIM_Num == 6)
	{
		TIM6_7_PeriClkCtrl(pTIMx->pTIM6_7, EnorDi);
	}
	else if(TIM_Num == 7)
	{
		TIM6_7_PeriClkCtrl(pTIMx->pTIM6_7, EnorDi);
	}
	else if(TIM_Num == 8)
	{
		TIM1_8_PeriClkCtrl(pTIMx->pTIM1_8, EnorDi);
	}
	else if(TIM_Num == 9)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
	else if(TIM_Num == 10)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
	else if(TIM_Num == 11)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
	else if(TIM_Num == 12)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
	else if(TIM_Num == 13)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
	else if(TIM_Num == 14)
	{
		TIM9_14_PeriClkCtrl(pTIMx->pTIM9_14, EnorDi);
	}
}

//TIM1 & TIM8
void TIM1_8_PeriClkCtrl(TIM1_8_RegDef_t *pTIM1_8, uint8_t EnorDi)
{
	if(EnorDi == ENABLE)
	{
		if(pTIM1_8 == TIM1)
		{
			TIM1_PCLK_EN();
		}
		else if(pTIM1_8 == TIM8)
		{
			TIM8_PCLK_EN();
		}

	}
	else
	{
		if(pTIM1_8 == TIM1)
		{
			TIM1_PCLK_DI();
		}
		else if(pTIM1_8 == TIM8)
		{
			TIM8_PCLK_DI();
		}

	}
}

//TIM2 to TIM5
void TIM2_5_PeriClkCtrl(TIM2_5_RegDef_t *pTIM2_5, uint8_t EnorDi)
{
	if(EnorDi == ENABLE)
	{
		if(pTIM2_5 == TIM2)
		{
			TIM2_PCLK_EN();
		}
		else if(pTIM2_5 == TIM3)
		{
			TIM3_PCLK_EN();
		}
		if(pTIM2_5 == TIM4)
		{
			TIM4_PCLK_EN();
		}
		else if(pTIM2_5 == TIM5)
		{
			TIM5_PCLK_EN();
		}

	}
	else
	{
		if(pTIM2_5 == TIM2)
		{
			TIM2_PCLK_DI();
		}
		else if(pTIM2_5 == TIM3)
		{
			TIM3_PCLK_DI();
		}
		if(pTIM2_5 == TIM4)
		{
			TIM4_PCLK_DI();
		}
		else if(pTIM2_5 == TIM5)
		{
			TIM5_PCLK_DI();
		}

	}
}

//TIM6 and TIM7
void TIM6_7_PeriClkCtrl(TIM6_7_RegDef_t *pTIM6_7, uint8_t EnorDi)
{
	if(EnorDi == ENABLE)
	{
		if(pTIM6_7 == TIM6)
		{
			TIM6_PCLK_EN();
		}
		else if(pTIM6_7 == TIM7)
		{
			TIM7_PCLK_EN();
		}

	}
	else
	{
		if(pTIM6_7 == TIM6)
		{
			TIM6_PCLK_DI();
		}
		else if(pTIM6_7 == TIM7)
		{
			TIM7_PCLK_DI();
		}

	}
}

//TIM9 to TIM14
void TIM9_14_PeriClkCtrl(TIM9_14_RegDef_t *pTIM9_14, uint8_t EnorDi)
{
	if(EnorDi == ENABLE)
	{
		if(pTIM9_14 == TIM9)
		{
			TIM9_PCLK_EN();
		}
		if(pTIM9_14 == TIM10)
		{
			TIM10_PCLK_EN();
		}
		else if(pTIM9_14 == TIM11)
		{
			TIM11_PCLK_EN();
		}
		else if(pTIM9_14 == TIM12)
		{
			TIM12_PCLK_EN();
		}
		if(pTIM9_14 == TIM13)
		{
			TIM13_PCLK_EN();
		}
		else if(pTIM9_14 == TIM14)
		{
			TIM14_PCLK_EN();
		}

	}
	else
	{
		if(pTIM9_14 == TIM9)
		{
			TIM9_PCLK_DI();
		}
		if(pTIM9_14 == TIM10)
		{
			TIM10_PCLK_DI();
		}
		else if(pTIM9_14 == TIM11)
		{
			TIM11_PCLK_DI();
		}
		else if(pTIM9_14 == TIM12)
		{
			TIM12_PCLK_DI();
		}
		if(pTIM9_14 == TIM13)
		{
			TIM13_PCLK_DI();
		}
		else if(pTIM9_14 == TIM14)
		{
			TIM14_PCLK_DI();
		}

	}
}

