/*
 * stm32f407xx_TIMx_driver.h
 *
 *  Created on: Jul 8, 2020
 *      Author: cchar
 */

#ifndef INC_STM32F407XX_TIMX_DRIVER_H_
#define INC_STM32F407XX_TIMX_DRIVER_H_

#include "stm32f407xx.h"

typedef struct
{
	uint8_t	 TIM_Channel;
	uint8_t  TIM_Mode;
	uint8_t  TIM_Pre_Load;
	uint8_t  TIM_Polarity;
	uint8_t  TIM_Align_mode;
	uint8_t	 TIM_Complementary;
	uint8_t	 TIM_DeadTime;
	uint8_t	 TIM_Break;
	uint8_t	 TIM_Clear_Evt;
	uint8_t	 TIM_Pulse;

}TIM1_8_Config_t;


typedef struct
{
	uint8_t	 TIM_Channel;
	uint8_t  TIM_Mode;
	uint8_t  TIM_Pre_Load;
	uint8_t  TIM_Polarity;
	uint8_t  TIM_Align_mode;

}TIM2_5_Config_t;

typedef struct
{


}TIM9_14_Config_t;

/*typedef struct
{


}TIM10_14_Config_t;
*/

typedef struct
{


}TIM6_7_Config_t;


typedef struct
{
	TIM1_8_RegDef_t 	*pTIM1_8;
	TIM2_5_RegDef_t		*pTIM2_5;
	TIM6_7_RegDef_t		*pTIM6_7;
	TIM9_14_RegDef_t	*pTIM9_14;

}TIMx_RegDef_t;

/*
 *Handle structure for TIMxx peripheral
 */
typedef struct
{

	TIM1_8_Config_t 	TIM1_8_Config;
	TIM2_5_Config_t 	TIM2_5_Config;
	TIM9_14_RegDef_t 	TIM9_14_Config;
	TIM6_7_Config_t 	TIM6_7_Config;


}TIMx_Handle_t;


/*
 * Macro Prototypes
 */


//enables or disables peripheral clock for the TIM1 and TIM8
void TIM1_8_PeriClkCtrl(TIM1_8_RegDef_t *pTIM1_8, uint8_t EnorDi);

//enables or disables peripheral clock for the TIM2 to TIM5
void TIM2_5_PeriClkCtrl(TIM2_5_RegDef_t *pTIM2_5, uint8_t EnorDi);

//enables or disables peripheral clock for the TIM6 and TIM7
void TIM6_7_PeriClkCtrl(TIM6_7_RegDef_t *pTIM6_7, uint8_t EnorDi);

//enables or disables peripheral clock for the TIM9 to TIM14
void TIM9_14_PeriClkCtrl(TIM9_14_RegDef_t *pTIM9_14, uint8_t EnorDi);

//Enables TIM clk based on which TIMx is used.

void TIMx_PeriClkCtrl(TIMx_RegDef_t *pTIMx, uint8_t TIM_Num, uint8_t EnorDi);

#endif /* INC_STM32F407XX_TIMX_DRIVER_H_ */
