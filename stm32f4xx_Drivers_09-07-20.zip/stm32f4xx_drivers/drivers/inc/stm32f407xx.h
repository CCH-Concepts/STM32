/*
 * stm32f407xx.h
 *
 *  Created on: May 15, 2020
 *      Author: cchar
 */

#ifndef INC_STM32F407XX_H_
#define INC_STM32F407XX_H_

#include<stddef.h>
#include<stdint.h>

/*********************************Start: Processor specific Details ***********************************
 *
 * ARM Cortex Mx Processor NVIC ISERx Register Addresses
 */

#define NVIC_ISER0				 ((volatile uint32_t*)0xE000E100)
#define NVIC_ISER1				 ((volatile uint32_t*)0xE000E104)
#define NVIC_ISER2				 ((volatile uint32_t*)0xE000E108)
#define NVIC_ISER3				 ((volatile uint32_t*)0xE000E10C)

#define NVIC_ICER0				 ((volatile uint32_t*)0xE000E180)
#define NVIC_ICER1				 ((volatile uint32_t*)0xE000E184)
#define NVIC_ICER2				 ((volatile uint32_t*)0xE000E188)
#define NVIC_ICER3				 ((volatile uint32_t*)0xE000E18C)

/*
 * ARM Cortex Mx Processor Priority register address calc
 */

#define NVIC_PR_BASEADDR		 ((volatile uint32_t*)0xE000E400)

/*
 * ARM Cortex Mx Processor number of priority bits implemented in priority register.
 */

#define	NO_PR_BITS_IMPLEMENTED	4

/*
 * base address of flash and SRAM memories
 */

#define FLASH_BASEADDR			0x08000000U
#define SRAM1_BASEADDR			0x20000000U //112kb
#define SRAM2_BASEADDR			0x20001C00U // SRAM1_BASEADDR + 112kb
#define ROM_BASEADDR			0x1FFF0000U
#define OTP_BASEADDR			0x1fff7800U
#define SRAM 					SRAM1_BASEADDR


#define PERIPH_BASE				0x40000000U
#define APB1PERIPH_BASE			0x40000000U
#define APB2PERIPH_BASE			0x40010000U
#define AHB1PERIPH_BASE			0x40020000U
#define AHB2PERIPH_BASE			0x50000000U

//base address of peripherals which are hanging off of AHB1 bus.
#define GPIOA_BASEADDR			(AHB1PERIPH_BASE + 0x0000)
#define GPIOB_BASEADDR			(AHB1PERIPH_BASE + 0x0400)
#define GPIOC_BASEADDR			(AHB1PERIPH_BASE + 0x0800)
#define GPIOD_BASEADDR			(AHB1PERIPH_BASE + 0x0C00)
#define GPIOE_BASEADDR			(AHB1PERIPH_BASE + 0x1000)
#define GPIOF_BASEADDR			(AHB1PERIPH_BASE + 0x1400)
#define GPIOG_BASEADDR			(AHB1PERIPH_BASE + 0x1800)
#define GPIOH_BASEADDR			(AHB1PERIPH_BASE + 0x1C00)
#define GPIOI_BASEADDR			(AHB1PERIPH_BASE + 0x2000)
#define RCC_BASEADDR			(AHB1PERIPH_BASE + 0x3800)



//base address of peripherals which are hanging off of APB1 bus.
#define I2C1_BASEADDR			(APB1PERIPH_BASE + 0x5400)
#define I2C2_BASEADDR			(APB1PERIPH_BASE + 0x5800)
#define I2C3_BASEADDR			(APB1PERIPH_BASE + 0x5C00)

#define SPI2_BASEADDR			(APB1PERIPH_BASE + 0x3800)
#define SPI3_BASEADDR			(APB1PERIPH_BASE + 0x3C00)

#define USART2_BASEADDR			(APB1PERIPH_BASE + 0x4400)
#define USART3_BASEADDR			(APB1PERIPH_BASE + 0x4800)

#define UART4_BASEADDR			(APB1PERIPH_BASE + 0x4C00)
#define UART5_BASEADDR			(APB1PERIPH_BASE + 0x5000)

#define TIM2_BASEADDR			(APB1PERIPH_BASE + 0x0000)
#define TIM3_BASEADDR			(APB1PERIPH_BASE + 0x0400)
#define TIM4_BASEADDR			(APB1PERIPH_BASE + 0x0800)
#define TIM5_BASEADDR			(APB1PERIPH_BASE + 0x0C00)


#define TIM6_BASEADDR			(APB1PERIPH_BASE + 0x1000)
#define TIM7_BASEADDR			(APB1PERIPH_BASE + 0x1400)

#define TIM12_BASEADDR			(APB1PERIPH_BASE + 0x2000)
#define TIM13_BASEADDR			(APB1PERIPH_BASE + 0x1C00)
#define TIM14_BASEADDR			(APB1PERIPH_BASE + 0x1800)

//base address of peripherals which are hanging off of APB2 bus.
#define SPI1_BASEADDR			(APB2PERIPH_BASE + 0x3000)
#define USART1_BASEADDR			(APB2PERIPH_BASE + 0x1000)
#define USART6_BASEADDR			(APB2PERIPH_BASE + 0x1400)
#define EXTI_BASEADDR			(APB2PERIPH_BASE + 0x3C00)
#define SYSCFG_BASEADDR			(APB2PERIPH_BASE + 0x3800)

#define TIM1_BASEADDR			(APB2PERIPH_BASE + 0x0000)
#define TIM8_BASEADDR			(APB2PERIPH_BASE + 0x0400)
#define TIM9_BASEADDR			(APB2PERIPH_BASE + 0x4000)
#define TIM10_BASEADDR			(APB2PERIPH_BASE + 0x4400)
#define TIM11_BASEADDR			(APB2PERIPH_BASE + 0x4800)


//GPIO register structure
typedef struct
{
	volatile uint32_t MODER;			/*!< GPIO port mode register 						Address offset: 0x00 */
	volatile uint32_t OTYPER;			/*!< GPIO port output type register 				Address offset: 0x04 */
	volatile uint32_t OSPEEDR;			/*!< GPIO port output speed register				Address offset: 0x08 */
	volatile uint32_t PUPDR;			/*!< GPIO port pull-up/pull-down register			Address offset: 0x0C */
	volatile uint32_t IDR;				/*!< GPIO port input data register					Address offset: 0x10 */
	volatile uint32_t ODR;				/*!< GPIO port output data register					Address offset: 0x14 */
	volatile uint32_t BSRR;				/*!< GPIO port bit set/reset register				Address offset: 0x18 */
	volatile uint32_t LCKR;				/*!< GPIO port configuration lock register 			Address offset: 0x1C */
	volatile uint32_t AFR[2];			/*!< AFR[0] : GPIO alternate function low register	Address offset: 0x20 */
										/*!< AFR[1] : GPIO alternate function High register	Address offset: 0x24 */
}GPIO_RegDef_t;

//TIMx register structure
//TIM1_8
typedef struct
{
	volatile uint32_t CR1;				/*!< Control register 1 								Address offset: 0x00 */
	volatile uint32_t CR2;				/*!< Control register 2				 					Address offset: 0x04 */
	volatile uint32_t CMCR;				/*!< TIM1 and TIM8 slave mode control register			Address offset: 0x08 */
	volatile uint32_t DIER;				/*!< TIM1 and TIM8 DMA/interrupt enable register		Address offset: 0x0C */
	volatile uint32_t SR;				/*!< TIM1 and TIM8 status register						Address offset: 0x10 */
	volatile uint32_t EGR;				/*!< TIM1 and TIM8 event generation register			Address offset: 0x14 */
	volatile uint32_t CCMR1;			/*!< TIM1 and TIM8 capture/compare mode register 1		Address offset: 0x18 */
	volatile uint32_t CCMR2;			/*!< TIM1 and TIM8 capture/compare mode register 2		Address offset: 0x1C */
	volatile uint32_t CCER;				/*!< TIM1 and TIM8 capture/compare enable register		Address offset: 0x20 */
	volatile uint32_t CNT;				/*!< TIM1 and TIM8 counter								Address offset: 0x24 */
	volatile uint32_t PSC;				/*!< TIM1 and TIM8 prescaler							Address offset: 0x28 */
	volatile uint32_t ARR;				/*!< TIM1 and TIM8 auto-reload register					Address offset: 0x2C */
	volatile uint32_t RCR;				/*!< TIM1 and TIM8 repetition counter register			Address offset: 0x30 */
	volatile uint32_t CCR1;				/*!< TIM1 and TIM8 capture/compare register 1			Address offset: 0x34 */
	volatile uint32_t CCR2;				/*!< TIM1 and TIM8 capture/compare register 2			Address offset: 0x38 */
	volatile uint32_t CCR3;				/*!< TIM1 and TIM8 capture/compare register 3			Address offset: 0x3C */
	volatile uint32_t CCR4;				/*!< TIM1 and TIM8 capture/compare register 4			Address offset: 0x40 */
	volatile uint32_t BDTR;				/*!< TIM1 and TIM8 break and dead-time register			Address offset: 0x44 */
	volatile uint32_t DCR;				/*!< TIM1 and TIM8 DMA control register					Address offset: 0x48 */
	volatile uint32_t DMAR;				/*!< TIM1 and TIM8 DMA address for full transfer		Address offset: 0x4C */

}TIM1_8_RegDef_t;

//TIM2_5
typedef struct
{
	volatile uint32_t CR1;				/*!< Control register 1 						Address offset: 0x00 */
	volatile uint32_t CR2;				/*!< Control register 2				 			Address offset: 0x04 */
	volatile uint32_t SMCR;				/*!< TIMx slave mode control register			Address offset: 0x08 */
	volatile uint32_t DIER;				/*!< TIMx DMA/interrupt enable register			Address offset: 0x0C */
	volatile uint32_t SR;				/*!< TIMx status register						Address offset: 0x10 */
	volatile uint32_t EGR;				/*!< TIMx event generation register				Address offset: 0x14 */
	volatile uint32_t CCMR1;			/*!< TIMx capture/compare mode register 1		Address offset: 0x18 */
	volatile uint32_t CCMR2;			/*!< TIMx capture/compare mode register 2		Address offset: 0x1C */
	volatile uint32_t CCER;				/*!< TIMx capture/compare enable register		Address offset: 0x20 */
	volatile uint32_t CNT;				/*!< TIMx counter								Address offset: 0x24 */
	volatile uint32_t PSC;				/*!< TIMx prescaler								Address offset: 0x28 */
	volatile uint32_t ARR;				/*!< TIMx auto-reload register					Address offset: 0x2C */
	uint32_t Reserved8;					/*!< reserved									Address offset: 0x30 */
	volatile uint32_t CCR1;				/*!< TIMx capture/compare register 1			Address offset: 0x34 */
	volatile uint32_t CCR2;				/*!< TIMx capture/compare register 2			Address offset: 0x38 */
	volatile uint32_t CCR3;				/*!< TIMx capture/compare register 3			Address offset: 0x3C */
	volatile uint32_t CCR4;				/*!< TIMx capture/compare register 4			Address offset: 0x40 */
	uint32_t Reserved9;					/*!< reserved									Address offset: 0x44 */
	volatile uint32_t DCR;				/*!< TIMx DMA control register					Address offset: 0x48 */
	volatile uint32_t DMAR;				/*!< TIMx DMA address for full transfer			Address offset: 0x4C */
	volatile uint32_t OR;				/*!< TIMx option register						Address offset: 0x50 */


}TIM2_5_RegDef_t;


//TIM9_14
typedef struct
{
	volatile uint32_t CR1;				/*!< Control register 1 						Address offset: 0x00 */
	uint32_t Reserved10;				/*!< reserved									Address offset: 0x04 */
	uint32_t Reserved11;				/*!< reserved									Address offset: 0x08 */
	volatile uint32_t DIER;				/*!< TIMx DMA/interrupt enable register			Address offset: 0x0C */
	volatile uint32_t SR;				/*!< TIMx status register						Address offset: 0x10 */
	volatile uint32_t EGR;				/*!< TIMx event generation register				Address offset: 0x14 */
	volatile uint32_t CCMR1;			/*!< TIMx capture/compare mode register 1		Address offset: 0x18 */
	uint32_t Reserved12;				/*!< reserved									Address offset: 0x1C */
	volatile uint32_t CCER;				/*!< TIMx capture/compare enable register		Address offset: 0x20 */
	volatile uint32_t CNT;				/*!< TIMx counter								Address offset: 0x24 */
	volatile uint32_t PSC;				/*!< TIMx prescaler								Address offset: 0x28 */
	volatile uint32_t ARR;				/*!< TIMx auto-reload register					Address offset: 0x2C */
	uint32_t Reserved13;				/*!< reserved									Address offset: 0x30 */
	volatile uint32_t CCR1;				/*!< TIMx capture/compare register 1			Address offset: 0x34 */
	uint32_t Reserved14[5];				/*!< reserved									Address offset: 0x38 to 0x4C */
	volatile uint32_t OR;				/*!< TIMx option register						Address offset: 0x50 */


}TIM9_14_RegDef_t;

//TIM6_7
typedef struct
{
	volatile uint32_t CR1;				/*!< Control register 1 						Address offset: 0x00 */
	volatile uint32_t CR2;				/*!< Control register 2							Address offset: 0x04 */
	uint32_t Reserved15;				/*!< reserved									Address offset: 0x08 */
	volatile uint32_t DIER;				/*!< TIMx DMA/interrupt enable register			Address offset: 0x0C */
	volatile uint32_t SR;				/*!< TIMx status register						Address offset: 0x10 */
	volatile uint32_t EGR;				/*!< TIMx event generation register				Address offset: 0x14 */
	uint32_t Reserved16[3];				/*!< reserved									Address offset: 0x18 to 0x20 */
	volatile uint32_t CNT;				/*!< TIMx counter								Address offset: 0x24 */
	volatile uint32_t PSC;				/*!< TIMx prescaler								Address offset: 0x28 */
	volatile uint32_t ARR;				/*!< TIMx auto-reload register					Address offset: 0x2C */

}TIM6_7_RegDef_t;

//RCC register structure
typedef struct
{
	volatile uint32_t CR;				/*!< RCC clock control register 								Address offset: 0x00 */
	volatile uint32_t PLLCFGR;			/*!< RCC PLL configuration register 							Address offset: 0x04 */
	volatile uint32_t CFGR;				/*!< RCC clock configuration register							Address offset: 0x08 */
	volatile uint32_t CIR;				/*!< RCC clock interrupt register								Address offset: 0x0C */
	volatile uint32_t AHB1RSTR;			/*!< RCC AHB1 peripheral reset register							Address offset: 0x10 */
	volatile uint32_t AHB2RSTR;			/*!< RCC AHB2 peripheral reset register							Address offset: 0x14 */
	volatile uint32_t AHB3RSTR;			/*!< RCC AHB3 peripheral reset register							Address offset: 0x18 */
	uint32_t Reserved0;					/*!< reserved													Address offset: 0x1C */
	volatile uint32_t APB1RSTR;			/*!< RCC APB1 peripheral reset register 						Address offset: 0x20 */
	volatile uint32_t APB2RSTR;			/*!< RCC APB2 peripheral reset register							Address offset: 0x24 */
	uint32_t Reserved1[2];				/*!< reserved													Address offset: 0x28 - 0x2C */
	volatile uint32_t AHB1ENR;			/*!< RCC AHB1 peripheral clock enable register					Address offset: 0x30 */
	volatile uint32_t AHB2ENR;			/*!< RCC AHB2 peripheral clock enable register					Address offset: 0x34 */
	volatile uint32_t AHB3ENR;			/*!< RCC AHB3 peripheral clock enable register					Address offset: 0x38 */
	uint32_t Reserved2;					/*!< reserved													Address offset: 0x3C */
	volatile uint32_t APB1ENR;			/*!< RCC APB1 peripheral clock enable register					Address offset: 0x40 */
	volatile uint32_t APB2ENR;			/*!< RCC APB2 peripheral clock enable register					Address offset: 0x44 */
	uint32_t Reserved3[2];				/*!< reserved													Address offset: 0x48 - 0x4C */
	volatile uint32_t AHB1LPENR;		/*!< RCC AHB1 peripheral clock enable in low power mode register		Address offset: 0x50 */
	volatile uint32_t AHB2LPENR;		/*!< RCC AHB2 peripheral clock enable in low power mode register		Address offset: 0x54 */
	volatile uint32_t AHB3LPENR;		/*!< RCC AHB3 peripheral clock enable in low power mode register		Address offset: 0x58 */
	uint32_t Reserved4;					/*!< reserved													Address offset: 0x5C */
	volatile uint32_t APB1LPENR;		/*!< RCC APB1 peripheral clock enable in low power mode register		Address offset: 0x60 */
	volatile uint32_t APB2LPENR;		/*!< RCC APB2 peripheral clock enable in low power mode register		Address offset: 0x64 */
	uint32_t Reserved5[2];				/*!< reserved													Address offset: 0x68 - 0x6C */
	volatile uint32_t BDCR;				/*!< RCC Backup domain control register							Address offset: 0x70 */
	volatile uint32_t CSR;				/*!< RCC clock control & status register						Address offset: 0x74 */
	uint32_t Reserved6[2];				/*!< reserved													Address offset: 0x78 - 0x7C */
	volatile uint32_t SSCGR;			/*!< RCC spread spectrum clock generation register				Address offset: 0x80 */
	volatile uint32_t PLLI2SCFGR;		/*!< RCC PLLI2S configuration register							Address offset: 0x84 */
	volatile uint32_t PLLSAICFGR;		/*!< RCC PLL configuration register								Address offset: 0x88 */
	volatile uint32_t RCC_DCKCFGR;		/*!< RCC Dedicated Clock Configuration Register					Address offset: 0x8C */


}RCC_RegDef_t;



//SYSCFG register structure
typedef struct
{
	volatile uint32_t MEMRMP;			/*!< config the type of memory accessible at add 0x0000 0000. 	Address offset: 0x00 */
	volatile uint32_t PCM;				/*!< Ethernet PHY interface selection							Address offset: 0x04 */
	volatile uint32_t EXTICR[4];		/*!< EXTIx[3:0]: EXTI x configuration (x = 0 to 3)				Address offset: 0x08 */
										/*!< EXTIx[3:0]: EXTI x configuration (x = 4 to 7)				Address offset: 0x0C */
										/*!< EXTIx[3:0]: EXTI x configuration (x = 8 to 11) 			Address offset: 0x10 */
										/*!< EXTIx[3:0]: EXTI x configuration (x = 12 to 15) 			Address offset: 0x14 */
	uint32_t Reserved6[2];				/*!< reserved													Address offset: 0x18 - 0x1C */
	volatile uint32_t CMPCR;			/*!< Config of compensation cell					 			Address offset: 0x20 */
	uint32_t Reserved7[2];				/*!< reserved													Address offset: 0x24 - 0x28 */
	volatile uint32_t CFGR;				/*!< Config of compensation cell					 			Address offset: 0x2C */
}SYSCFG_RegDef_t;

//EXTI register structure
typedef struct
{
	volatile uint32_t IMR;				/*!< Config Interrupt register Mask bits							Address offset: 0x00 */
	volatile uint32_t EMR;				/*!< Config Event register Mask bits							Address offset: 0x04 */
	volatile uint32_t RTSR;				/*!< Config Rising edge detection								Address offset: 0x08 */
	volatile uint32_t FTSR;				/*!< Config Falling edge detection								Address offset: 0x0C */
	volatile uint32_t SWIER;			/*!< Config software interrupt detection						Address offset: 0x10 */
	volatile uint32_t PR;				/*!< pending Bit Register										Address offset: 0x14 */
}EXTI_RegDef_t;


/*
 * Peripheral register definition for SPI
 */

typedef struct
{
	volatile uint32_t CR1;				/*!< Config SPI Control register 1								Address offset: 0x00 */
	volatile uint32_t CR2;				/*!< Config SPI Control register 2								Address offset: 0x04 */
	volatile uint32_t SR;				/*!< SPI Status Register										Address offset: 0x08 */
	volatile uint32_t DR;				/*!< SPI Data Register											Address offset: 0x0C */
	volatile uint32_t CRCPR;			/*!< SPI CRC polynomial register								Address offset: 0x10 */
	volatile uint32_t RXCRCR;			/*!< SPI RX CRC register										Address offset: 0x14 */
	volatile uint32_t TXCRCR;			/*!< SPI TX CRC register										Address offset: 0x18 */
	volatile uint32_t I2SCFGR;			/*!< SPI_I2S configuration register								Address offset: 0x1C */
	volatile uint32_t I2SPR;			/*!< SPI_I2S prescaler register									Address offset: 0x20 */
}SPI_RegDef_t;

/*
 * Peripheral register definition for I2C
 */

typedef struct
{
	volatile uint32_t CR1;				/*!< Config I2C Control register 1								Address offset: 0x00 */
	volatile uint32_t CR2;				/*!< Config I2C Control register 2								Address offset: 0x04 */
	volatile uint32_t OAR1;				/*!< I2C Own address register 1									Address offset: 0x08 */
	volatile uint32_t OAR2;				/*!< I2C Own address register 2									Address offset: 0x0C */
	volatile uint32_t DR;				/*!< I2C Data register											Address offset: 0x10 */
	volatile uint32_t SR1;				/*!< I2C Status register 1										Address offset: 0x14 */
	volatile uint32_t SR2;				/*!< I2C Status register 2										Address offset: 0x18 */
	volatile uint32_t CCR;				/*!< I2C Clock control register									Address offset: 0x1C */
	volatile uint32_t TRISE;			/*!< I2C TRISE register											Address offset: 0x20 */
	volatile uint32_t FLTR;				/*!< I2C FLTR register											Address offset: 0x24 */
}I2C_RegDef_t;


//peripheral definitions (peripherial base addresses typecasted to xxxx_RegDef_t)

#define GPIOA		((GPIO_RegDef_t*) GPIOA_BASEADDR)
#define GPIOB		((GPIO_RegDef_t*) GPIOB_BASEADDR)
#define GPIOC		((GPIO_RegDef_t*) GPIOC_BASEADDR)
#define GPIOD		((GPIO_RegDef_t*) GPIOD_BASEADDR)
#define GPIOE		((GPIO_RegDef_t*) GPIOE_BASEADDR)
#define GPIOF		((GPIO_RegDef_t*) GPIOF_BASEADDR)
#define GPIOG		((GPIO_RegDef_t*) GPIOG_BASEADDR)
#define GPIOH		((GPIO_RegDef_t*) GPIOH_BASEADDR)
#define GPIOI		((GPIO_RegDef_t*) GPIOI_BASEADDR)

#define RCC			((RCC_RegDef_t*)RCC_BASEADDR)

#define EXTI		((EXTI_RegDef_t*)EXTI_BASEADDR)

#define SYSCFG		((SYSCFG_RegDef_t*)SYSCFG_BASEADDR)

#define SPI1		((SPI_RegDef_t*)SPI1_BASEADDR)
#define SPI2		((SPI_RegDef_t*)SPI2_BASEADDR)
#define SPI3		((SPI_RegDef_t*)SPI3_BASEADDR)

#define I2C1		((I2C_RegDef_t*)I2C1_BASEADDR)
#define I2C2		((I2C_RegDef_t*)I2C2_BASEADDR)
#define I2C3		((I2C_RegDef_t*)I2C3_BASEADDR)

#define TIM1		((TIM1_8_RegDef_t*)TIM1_BASEADDR)
#define TIM2		((TIM2_5_RegDef_t*)TIM2_BASEADDR)
#define TIM3		((TIM2_5_RegDef_t*)TIM3_BASEADDR)
#define TIM4		((TIM2_5_RegDef_t*)TIM4_BASEADDR)
#define TIM5		((TIM2_5_RegDef_t*)TIM5_BASEADDR)
#define TIM6		((TIM6_7_RegDef_t*)TIM6_BASEADDR)
#define TIM7		((TIM6_7_RegDef_t*)TIM7_BASEADDR)
#define TIM8		((TIM1_8_RegDef_t*)TIM8_BASEADDR)
#define TIM9		((TIM9_14_RegDef_t*)TIM9_BASEADDR)
#define TIM10		((TIM9_14_RegDef_t*)TIM10_BASEADDR)
#define TIM11		((TIM9_14_RegDef_t*)TIM11_BASEADDR)
#define TIM12		((TIM9_14_RegDef_t*)TIM12_BASEADDR)
#define TIM13		((TIM9_14_RegDef_t*)TIM13_BASEADDR)
#define TIM14		((TIM9_14_RegDef_t*)TIM14_BASEADDR)


//Clock Enables macros for TIMx peripherals
//TIM2 to 7 & TIM12 to 14
#define TIM2_PCLK_EN() 		(RCC->APB1ENR |= (1<<0))
#define TIM3_PCLK_EN() 		(RCC->APB1ENR |= (1<<1))
#define TIM4_PCLK_EN() 		(RCC->APB1ENR |= (1<<2))
#define TIM5_PCLK_EN() 		(RCC->APB1ENR |= (1<<3))
#define TIM6_PCLK_EN() 		(RCC->APB1ENR |= (1<<4))
#define TIM7_PCLK_EN() 		(RCC->APB1ENR |= (1<<5))
#define TIM12_PCLK_EN() 	(RCC->APB1ENR |= (1<<6))
#define TIM13_PCLK_EN() 	(RCC->APB1ENR |= (1<<7))
#define TIM14_PCLK_EN() 	(RCC->APB1ENR |= (1<<8))

//TIM1 & 8 / TIM 9 to 11
#define TIM1_PCLK_EN() 		(RCC->APB2ENR |= (1<<0))
#define TIM8_PCLK_EN() 		(RCC->APB2ENR |= (1<<1))
#define TIM9_PCLK_EN() 		(RCC->APB2ENR |= (1<<16))
#define TIM10_PCLK_EN() 	(RCC->APB2ENR |= (1<<17))
#define TIM11_PCLK_EN() 	(RCC->APB2ENR |= (1<<18))


//Clock Enables macros for GPIOx peripherals

#define GPIOA_PCLK_EN() 	(RCC->AHB1ENR |= (1<<0))
#define GPIOB_PCLK_EN() 	(RCC->AHB1ENR |= (1<<1))
#define GPIOC_PCLK_EN() 	(RCC->AHB1ENR |= (1<<2))
#define GPIOD_PCLK_EN() 	(RCC->AHB1ENR |= (1<<3))
#define GPIOE_PCLK_EN() 	(RCC->AHB1ENR |= (1<<4))
#define GPIOF_PCLK_EN() 	(RCC->AHB1ENR |= (1<<5))
#define GPIOG_PCLK_EN() 	(RCC->AHB1ENR |= (1<<6))
#define GPIOH_PCLK_EN() 	(RCC->AHB1ENR |= (1<<7))
#define GPIOI_PCLK_EN() 	(RCC->AHB1ENR |= (1<<8))

//Clock Enables macros for I2Cx peripherals

#define I2C1_PCLK_EN() 		(RCC->APB1ENR |= (1<<21))
#define I2C2_PCLK_EN() 		(RCC->APB1ENR |= (1<<22))
#define I2C3_PCLK_EN() 		(RCC->APB1ENR |= (1<<23))

//Clock Enables macros for SPIx peripherals

#define SPI1_PCLK_EN() 		(RCC->APB2ENR |= (1<<12))
#define SPI2_PCLK_EN() 		(RCC->APB1ENR |= (1<<14))
#define SPI3_PCLK_EN() 		(RCC->APB1ENR |= (1<<15))

//Clock Enables macros for UARTx/USARTx peripherals

#define USART1_PCLK_EN() 	(RCC->APB2ENR |= (1<<4))
#define USART2_PCLK_EN() 	(RCC->APB1ENR |= (1<<17))
#define USART3_PCLK_EN() 	(RCC->APB1ENR |= (1<<18))
#define UART4_PCLK_EN() 	(RCC->APB1ENR |= (1<<19))
#define UART5_PCLK_EN() 	(RCC->APB1ENR |= (1<<20))
#define USART6_PCLK_EN() 	(RCC->APB2ENR |= (1<<5))

//Clock Enables macros for SYSCFG peripherals

#define SYSCFG_PCLK_EN() (RCC->APB2ENR |= (1<<14))

//Clock disables macros for GPIOx peripherals

#define GPIOA_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<0))
#define GPIOB_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<1))
#define GPIOC_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<2))
#define GPIOD_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<3))
#define GPIOE_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<4))
#define GPIOF_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<5))
#define GPIOG_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<6))
#define GPIOH_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<7))
#define GPIOI_PCLK_DI() 	(RCC->AHB1ENR &= ~(1<<8))

//Clock |Disables macros for I2Cx peripherals

#define I2C1_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<21))
#define I2C2_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<22))
#define I2C3_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<23))

//Clock Disables macros for SPIx peripherals

#define SPI1_PCLK_DI() 		(RCC->APB2ENR &= ~(1<<12))
#define SPI2_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<14))
#define SPI3_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<15))

//Clock Disables macros for UARTx/USARTx peripherals

#define USART1_PCLK_DI() 	(RCC->APB2ENR &= ~(1<<4))
#define USART2_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<17))
#define USART3_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<18))
#define UART4_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<19))
#define UART5_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<20))
#define USART6_PCLK_DI() 	(RCC->APB2ENR &= ~(1<<5))


//Clock Disables macros for TIMx peripherals
//TIM2 to 7 & TIM12 to 14
#define TIM2_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<0))
#define TIM3_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<1))
#define TIM4_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<2))
#define TIM5_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<3))
#define TIM6_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<4))
#define TIM7_PCLK_DI() 		(RCC->APB1ENR &= ~(1<<5))
#define TIM12_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<6))
#define TIM13_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<7))
#define TIM14_PCLK_DI() 	(RCC->APB1ENR &= ~(1<<8))

//TIM1 & 8 / TIM 9 to 11
#define TIM1_PCLK_DI() 		(RCC->APB2ENR &= ~(1<<0))
#define TIM8_PCLK_DI() 		(RCC->APB2ENR &= ~(1<<1))
#define TIM9_PCLK_DI() 		(RCC->APB2ENR &= ~(1<<16))
#define TIM10_PCLK_DI() 	(RCC->APB2ENR &= ~(1<<17))
#define TIM11_PCLK_DI() 	(RCC->APB2ENR &= ~(1<<18))


//Clock Enables macros for SYSCFG peripherals

#define SYSCFG_PCLK_DI() 	(RCC->APB2ENR &= ~(1<<14))

#define ENABLE 			1
#define DISABLE 		0
#define SET				ENABLE
#define RESET			DISABLE
#define GPIO_PIN_SET	SET
#define GPIO_PIN_RESET	RESET
#define FLAG_SET		SET
#define FLAG_RESET		RESET

//Macros to reset GPIOx Peripherals

#define GPIOA_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<0));	(RCC->AHB1RSTR &= ~(1<<0));}while(0)
#define GPIOB_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<1));	(RCC->AHB1RSTR &= ~(1<<1));}while(0)
#define GPIOC_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<2));	(RCC->AHB1RSTR &= ~(1<<2));}while(0)
#define GPIOD_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<3));	(RCC->AHB1RSTR &= ~(1<<3));}while(0)
#define GPIOE_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<4));	(RCC->AHB1RSTR &= ~(1<<4));}while(0)
#define GPIOF_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<5));	(RCC->AHB1RSTR &= ~(1<<5));}while(0)
#define GPIOG_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<6));	(RCC->AHB1RSTR &= ~(1<<6));}while(0)
#define GPIOH_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<7));	(RCC->AHB1RSTR &= ~(1<<7));}while(0)
#define GPIOI_REG_RESET()	do{(RCC->AHB1RSTR |= (1<<8));	(RCC->AHB1RSTR &= ~(1<<8));}while(0)

//this macro returns a code between 0 to 8 for a given GPIO base address.

#define GPIO_BASEADDR_TO_CODE(x)	((x == GPIOA)?0:\
									 (x == GPIOB)?1:\
									 (x == GPIOC)?2:\
									 (x == GPIOD)?3:\
									 (x == GPIOE)?4:\
									 (x == GPIOF)?5:\
									 (x == GPIOG)?6:\
									 (x == GPIOH)?7:\
									 (x == GPIOI)?8:0)


//IRQ numbers of STM32F407xx MCU

#define IRQ_NO_EXTI0		6
#define IRQ_NO_EXTI1		7
#define IRQ_NO_EXTI2		8
#define IRQ_NO_EXTI3		9
#define IRQ_NO_EXTI4		10
#define IRQ_NO_EXTI9_5		23
#define IRQ_NO_EXTI15_10	40

#define IRQ_NO_SPI1			35
#define IRQ_NO_SPI2			36
#define IRQ_NO_SPI3			51



/*
 * macros for all the IRQ priority levels
 */

#define NVIC_IRQ_PRI0		0
#define NVIC_IRQ_PRI1		1
#define NVIC_IRQ_PRI2		2
#define NVIC_IRQ_PRI3		3
#define NVIC_IRQ_PRI4		4
#define NVIC_IRQ_PRI5		5
#define NVIC_IRQ_PRI6		6
#define NVIC_IRQ_PRI7		7
#define NVIC_IRQ_PRI8		8
#define NVIC_IRQ_PRI9		9
#define NVIC_IRQ_PRI10		10
#define NVIC_IRQ_PRI11		11
#define NVIC_IRQ_PRI12		12
#define NVIC_IRQ_PRI13		13
#define NVIC_IRQ_PRI14		14
#define NVIC_IRQ_PRI15		15
#define NVIC_IRQ_PRI16		16
#define NVIC_IRQ_PRI17		17
#define NVIC_IRQ_PRI18		18
#define NVIC_IRQ_PRI19		19

/*
 * Bit definitions of SPI peripherals
 */

#define SPI_CR1_CPHA		0
#define SPI_CR1_CPOL		1
#define SPI_CR1_MAST		2
#define SPI_CR1_BR			3
#define SPI_CR1_SPE			6
#define SPI_CR1_LSBFIRST	7
#define SPI_CR1_SSI			8
#define SPI_CR1_SSM			9
#define SPI_CR1_RXONLY		10
#define SPI_CR1_DFF			11
#define SPI_CR1_CRCNEXT		12
#define SPI_CR1_CRCEN		13
#define SPI_CR1_BIDIOE		14
#define SPI_CR1_BIDIMODE	15

#define SPI_CR2_RXDMAEN		0
#define SPI_CR2_TXDMAEN		1
#define SPI_CR2_SSOE		2
#define SPI_CR2_FRF			4
#define SPI_CR2_ERRIE		5
#define SPI_CR2_RXNEIE		6
#define SPI_CR2_TXEIE		7

#define SPI_SR_RXNE			0
#define SPI_SR_TXE			1
#define SPI_SR_CHSIDE		2
#define SPI_SR_UDR			3
#define SPI_SR_CRCERR		4
#define SPI_SR_MODF			5
#define SPI_SR_OVR			6
#define SPI_SR_BSY			7
#define SPI_SR_FRE			8

/*
 * Bit definitions of I2C peripherals
 */

/*
 * Bit position definitions I2C_CR1
 */
#define I2C_CR1_PE			0
#define I2C_CR1_SMBUS		1
#define I2C_CR1_SMBTYPE		3
#define I2C_CR1_ENARP		4
#define I2C_CR1_ENPEC		5
#define I2C_CR1_ENGC		6
#define I2C_CR1_NOSTRETCH	7
#define I2C_CR1_START		8
#define I2C_CR1_STOP		9
#define I2C_CR1_ACK			10
#define I2C_CR1_POS			11
#define I2C_CR1_PEC			12
#define I2C_CR1_ALERT		13
#define I2C_CR1_SWRST		15

/*
 * Bit position definitions I2C_CR2
 */

#define SPI_CR2_FREQ0_5		0
#define SPI_CR2_TERREN		8
#define SPI_CR2_ITEVTEN		9
#define SPI_CR2_ITBUFEN		10
#define SPI_CR2_DMAEN		11
#define SPI_CR2_LAST		12

/*
 * Bit position definitions I2C_OAR1
 */
#define I2C_OAR1_ADD0    				 0
#define I2C_OAR1_ADD71 				 	 1
#define I2C_OAR1_ADD98  			 	 8
#define I2C_OAR1_ADDMODE   			 	15

/*
 * Bit position definitions I2C_SR1
 */

#define I2C_SR1_SB 					 	0
#define I2C_SR1_ADDR 				 	1
#define I2C_SR1_BTF 					2
#define I2C_SR1_ADD10 					3
#define I2C_SR1_STOPF 					4
#define I2C_SR1_RXNE 					6
#define I2C_SR1_TXE 					7
#define I2C_SR1_BERR 					8
#define I2C_SR1_ARLO 					9
#define I2C_SR1_AF 					 	10
#define I2C_SR1_OVR 					11
#define I2C_SR1_TIMEOUT 				14

/*
 * Bit position definitions I2C_SR2
 */
#define I2C_SR2_MSL						0
#define I2C_SR2_BUSY 					1
#define I2C_SR2_TRA 					2
#define I2C_SR2_GENCALL 				4
#define I2C_SR2_DUALF 					7

/*
 * Bit position definitions I2C_CCR
 */
#define I2C_CCR_CCR 					 0
#define I2C_CCR_DUTY 					14
#define I2C_CCR_FS  				 	15

/*
 * Bit position definitions TIM1_8
 */

//CR1
#define TIM1_8_CR1_CEN 					 0
#define TIM1_8_CR1_UDIS 				 1
#define TIM1_8_CR1_URS 					 2
#define TIM1_8_CR1_OPM 					 3
#define TIM1_8_CR1_DIR 					 4
#define TIM1_8_CR1_CMS	 				 5
#define TIM1_8_CR1_ARPE 				 7
#define TIM1_8_CR1_CKD	 				 8

// SMCR
#define TIM1_8_SMCR_SMS 				 0
#define TIM1_8_SMCR_TS	 				 4
#define TIM1_8_SMCR_MSM 				 7
#define TIM1_8_SMCR_ETF 				 8
#define TIM1_8_SMCR_ETPS	 			 12
#define TIM1_8_SMCR_ECE					 14
#define TIM1_8_SMCR_ETP					 15

//EGR
#define TIM1_8_EGR_UG 					 0
#define TIM1_8_EGR_CC1G 				 1
#define TIM1_8_EGR_CC2G 				 2
#define TIM1_8_EGR_CC3G					 3
#define TIM1_8_EGR_CC4G 				 4
#define TIM1_8_EGR_COMG 				 5
#define TIM1_8_EGR_TG 					 6
#define TIM1_8_EGR_BG	 				 7

//CCMR1
#define TIM1_8_CCMR1_CC1	 			 0
#define TIM1_8_CCMR1_OC1FE 				 2
#define TIM1_8_CCMR1_OC1PE 				 3
#define TIM1_8_CCMR1_OC1M				 4
#define TIM1_8_CCMR1_OC1CE 				 7
#define TIM1_8_CCMR1_CC2S	 			 8
#define TIM1_8_CCMR1_OC2FE 				 10
#define TIM1_8_CCMR1_OC2PE 				 11
#define TIM1_8_CCMR1_OC2M				 12
#define TIM1_8_CCMR1_OC2CE 				 15

//CCMR2
#define TIM1_8_CCMR2_CC3				 0
#define TIM1_8_CCMR2_OC3FE 				 2
#define TIM1_8_CCMR2_OC3PE 				 3
#define TIM1_8_CCMR2_OC3M				 4
#define TIM1_8_CCMR2_OC3CE 				 7
#define TIM1_8_CCMR2_CC4	 			 8
#define TIM1_8_CCMR2_OC4FE 				 10
#define TIM1_8_CCMR2_OC4PE 				 11
#define TIM1_8_CCMR2_OC4M				 12
#define TIM1_8_CCMR2_OC4CE 				 15

//CCER
#define TIM1_8_CCMR2_CC1E	 			 0
#define TIM1_8_CCMR2_CC1P 				 1
#define TIM1_8_CCMR2_CC1NE 				 2
#define TIM1_8_CCMR2_CC1NP				 3
#define TIM1_8_CCMR2_CC2E 				 4
#define TIM1_8_CCMR2_CC2P	 			 5
#define TIM1_8_CCMR2_CC2NE 				 6
#define TIM1_8_CCMR2_CC2NP 				 7
#define TIM1_8_CCMR2_CC3E			 	 8
#define TIM1_8_CCMR2_CC3P 				 9
#define TIM1_8_CCMR2_CC3NE 				 10
#define TIM1_8_CCMR2_CC3NP 				 11
#define TIM1_8_CCMR2_CC4E			 	 12
#define TIM1_8_CCMR2_CC4P 				 13


/*
 * Bit position definitions TIM2_5
 */

//CR1
#define TIM2_5_CR1_CEN 					 0
#define TIM2_5_CR1_UDIS 				 1
#define TIM2_5_CR1_URS 					 2
#define TIM2_5_CR1_OPM 					 3
#define TIM2_5_CR1_DIR 					 4
#define TIM2_5_CR1_CMS	 				 5
#define TIM2_5_CR1_ARPE 				 7
#define TIM2_5_CR1_CKD	 				 8

// SMCR
#define TIM2_5_SMCR_SMS	 				 0
#define TIM2_5_SMCR_TS	 				 4
#define TIM2_5_SMCR_MSM 				 7
#define TIM2_5_SMCR_ETF	 				 8
#define TIM2_5_SMCR_ETPS	 			 12
#define TIM2_5_SMCR_ECE					 14
#define TIM2_5_SMCR_ETP					 15

//EGR
#define TIM2_5_EGR_UG 					 0
#define TIM2_5_EGR_CC1G 				 1
#define TIM2_5_EGR_CC2G 				 2
#define TIM2_5_EGR_CC3G					 3
#define TIM2_5_EGR_CC4G 				 4
#define TIM2_5_EGR_TG 					 6


//CCMR1
#define TIM2_5_CCMR1_CC1	 			 0
#define TIM2_5_CCMR1_OC1FE 				 2
#define TIM2_5_CCMR1_OC1PE 				 3
#define TIM2_5_CCMR1_OC1M				 4
#define TIM2_5_CCMR1_OC1CE 				 7
#define TIM2_5_CCMR1_CC2S	 			 8
#define TIM2_5_CCMR1_OC2FE 				 10
#define TIM2_5_CCMR1_OC2PE 				 11
#define TIM2_5_CCMR1_OC2M				 12
#define TIM2_5_CCMR1_OC2CE 				 15

//CCMR2
#define TIM2_5_CCMR2_CC3	 			 0
#define TIM2_5_CCMR2_OC3FE 				 2
#define TIM2_5_CCMR2_OC3PE 				 3
#define TIM2_5_CCMR2_OC3M				 4
#define TIM2_5_CCMR2_OC3CE 				 7
#define TIM2_5_CCMR2_CC4	 			 8
#define TIM2_5_CCMR2_OC4FE 				 10
#define TIM2_5_CCMR2_OC4PE 				 11
#define TIM2_5_CCMR2_OC4M				 12
#define TIM2_5_CCMR2_OC4CE 				 15

//CCER
#define TIM2_5_CCMR2_CC1E	 			 0
#define TIM2_5_CCMR2_CC1P 				 1
#define TIM2_5_CCMR2_CC1NP				 3
#define TIM2_5_CCMR2_CC2E 				 4
#define TIM2_5_CCMR2_CC2P	 			 5
#define TIM2_5_CCMR2_CC2NP 				 7
#define TIM2_5_CCMR2_CC3E			 	 8
#define TIM2_5_CCMR2_CC3P 				 9
#define TIM2_5_CCMR2_CC3NP 				 11
#define TIM2_5_CCMR2_CC4E			 	 12
#define TIM2_5_CCMR2_CC4P 				 13
#define TIM2_5_CCMR2_CC4NP 				 15

/*
 * Bit position definitions TIM9/12
 */

//CR1
#define TIM9_12_CR1_CEN 				 0
#define TIM9_12_CR1_UDIS 				 1
#define TIM9_12_CR1_URS 				 2
#define TIM9_12_CR1_OPM 				 3
#define TIM9_12_CR1_ARPE 				 7
#define TIM9_12_CR1_CKD	 				 8

// SMCR
#define TIM9_12_SMCR_SMS				 0
#define TIM9_12_SMCR_TS					 4
#define TIM9_12_SMCR_MSM 				 7


//EGR
#define TIM9_12_EGR_UG 					 0
#define TIM9_12_EGR_CC1G 				 1
#define TIM9_12_EGR_CC2G 				 2
#define TIM9_12_EGR_TG 					 6


//CCMR1
#define TIM9_12_CCMR1_CC1	 			 0
#define TIM9_12_CCMR1_OC1FE 			 2
#define TIM9_12_CCMR1_OC1PE 			 3
#define TIM9_12_CCMR1_OC1M				 4
#define TIM9_12_CCMR1_CC2S				 8
#define TIM9_12_CCMR1_OC2FE 			 10
#define TIM9_12_CCMR1_OC2PE 			 11
#define TIM9_12_CCMR1_OC2M				 12



//CCER
#define TIM2_5_CCMR2_CC1E	 			 0
#define TIM2_5_CCMR2_CC1P 				 1
#define TIM2_5_CCMR2_CC1NP				 3
#define TIM2_5_CCMR2_CC2E 				 4
#define TIM2_5_CCMR2_CC2P	 			 5
#define TIM2_5_CCMR2_CC2NP 				 7

/*
 * Bit position definitions TIM10_14
 */

//CR1
#define TIM10_14_CR1_CEN 				 0
#define TIM10_14_CR1_UDIS 				 1
#define TIM10_14_CR1_URS 				 2
#define TIM10_14_CR1_OPM 				 3
#define TIM10_14_CR1_ARPE 				 7
#define TIM10_14_CR1_CKD	 			 8


//EGR
#define TIM10_14_EGR_UG 				 0
#define TIM10_14_EGR_CC1G 				 1



//CCMR1
#define TIM10_14_CCMR1_CC1	 			 0
#define TIM10_14_CCMR1_IC2PSC			 2
#define TIM10_14_CCMR1_IC1F				 4



//CCER
#define TIM10_14_CCMR2_CC1E	 			 0
#define TIM10_14_CCMR2_CC1P 			 1
#define TIM10_14_CCMR2_CC1NP			 3

/*
 * Bit position definitions TIM6_7
 */

//CR1
#define TIM6_7_CR1_CEN					 0
#define TIM6_7_CR1_UDIS 				 1
#define TIM6_7_CR1_URS 					 2
#define TIM6_7_CR1_OPM 					 3
#define TIM6_7_CR1_ARPE 				 7



//EGR
#define TIM6_7_EGR_UG 					 0



#include "stm32f407xx_gpio_driver.h"
#include "stm32f407xx_SPI_driver.h"
#include "stm32f407xx_i2c_driver.h"
#include "stm32f407xx_TIMx_driver.h"

#endif /* INC_STM32F407XX_H_ */
