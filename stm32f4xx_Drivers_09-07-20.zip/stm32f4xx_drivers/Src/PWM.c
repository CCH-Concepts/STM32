/*
 * PWM.c
 *
 *  Created on: 3 Jul 2020
 *      Author: cchar
 */
#include "stm32f407xx.h"

void delay(void)
{
	for(uint32_t i=0; i<50000; i++);
}

int main(void)
{
	GPIO_Handle_t GpioLED1,GpioBtn;


	GPIO_PeriClkCtrl(GPIOD, ENABLE);
	GPIO_PeriClkCtrl(GPIOA, ENABLE);
	TIMx_PeriClkCtrl(TIM4, 4, ENABLE);



	GpioLED1.pGPIOx = GPIOD;
	GpioLED1.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_12;
	GpioLED1.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLED1.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	GpioLED1.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLED1.GPIO_PinConfig.GPIO_PinPuPdControl =  GPIO_NO_PUPD;




	GpioBtn.pGPIOx = GPIOA;
	GpioBtn.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	GpioBtn.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_IN;
	GpioBtn.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	GpioBtn.GPIO_PinConfig.GPIO_PinPuPdControl =  GPIO_NO_PUPD;

	GPIO_Init(&GpioLED1);

	GPIO_Init(&GpioBtn);

	while(1)
	{
		if(GPIO_ReadFromInputPin(GPIOA, GPIO_PIN_NO_0)== 1)
		{
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
			delay();

		}


	}

	return 0;

}
